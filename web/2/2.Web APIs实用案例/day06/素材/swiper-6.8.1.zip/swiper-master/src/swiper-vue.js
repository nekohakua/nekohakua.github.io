import { Swiper } from './vue/swiper';
import { SwiperSlide } from './vue/swiper-slide';

export { Swiper, SwiperSlide };
